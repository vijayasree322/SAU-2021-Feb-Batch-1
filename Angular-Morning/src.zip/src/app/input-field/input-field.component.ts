import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-input-field',
  templateUrl: './input-field.component.html',
  styleUrls: ['./input-field.component.css']
})
export class InputFieldComponent implements OnInit {
  input_text :any;
  logs : Array<any> = [];
  
  onInputChange(event)
  {
    this.input_text = event;
    this.logs.push({key_pressed_at : new Date() ,text : event});
  //  console.log(event);
  }
  constructor() { }

  ngOnInit(): void {
  }
 

}
