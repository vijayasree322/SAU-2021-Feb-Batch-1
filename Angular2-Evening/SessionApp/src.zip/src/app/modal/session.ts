export interface Session {
    sessionName: string;
    instructorName : string;
    description : string;
}