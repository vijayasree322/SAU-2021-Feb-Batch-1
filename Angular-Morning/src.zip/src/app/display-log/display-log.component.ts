import { Component,Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-display-log',
  templateUrl: './display-log.component.html',
  styleUrls: ['./display-log.component.css']
})
export class DisplayLogComponent implements OnInit {
  @Input('logs') logs : any ;

  constructor() { }

  ngOnInit(): void {
  }

}
