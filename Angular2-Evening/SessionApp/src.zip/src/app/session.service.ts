import { Injectable } from '@angular/core';
import {Session} from '../app/modal/session'

@Injectable({
  providedIn: 'root'
})
export class SessionService {
  
  sessions:Session[]=
  [
    {
      sessionName:'Git',
      instructorName:'Biresh Kumar',
      description:'It is sessionon how to push code to github and clone it and commit a file and pull a file from github'
    },
    {
      sessionName:'Javascript',
      instructorName:'Rahul',
      description:'It is sessionon on javascript on let,var and array methods and regrex'
    },
    {
      sessionName: 'Angular 2',
      instructorName: 'Santhosh Kalisamy',
      description: 'Routing,Reactive forms,material designs',
    },
    {
      sessionName: 'Angular 1',
      instructorName: 'Raviteja V',
      description: 'Angular structure,workflow,event binding,property binding',
    },
  ]

  constructor() { }
  getSession()
  {
    return this.sessions;
  }
  addSession(session:Session)
  {
    this.sessions.push(session);
  }
  editSession(oldSession:Session,newSession:Session){
    const index = this.sessions.indexOf(oldSession);
    this.sessions[index] = newSession;
  }
  deleteSession(session:Session){
    const index = this.sessions.indexOf(session);
    this.sessions.splice(index, 1);
  }
}
